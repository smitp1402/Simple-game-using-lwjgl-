package essentials101;


public class Timer {	
	public static double getTime() {
		return (double)System.currentTimeMillis() / (double)1000L;
	}
}
