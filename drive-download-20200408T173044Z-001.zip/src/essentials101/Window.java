package essentials101;


import static org.lwjgl.glfw.GLFW.*;

import org.lwjgl.glfw.GLFWErrorCallback;
import org.lwjgl.glfw.GLFWVidMode;

public class Window {
	private long window;
	
	private int width;
	private int height;
	private boolean fullscreen;
	
	Input input;	
	
	public Window() {
		setSize(700,700);  
		setFullscreen(false);
	}
	
	public void setCallbacks() {
		glfwSetErrorCallback( new GLFWErrorCallback() {
			@Override
			public void invoke(int error, long description) {
				throw new IllegalStateException(GLFWErrorCallback.getDescription(description));
			}
		});
	}
	
	public void createWindow(String title) {
		
		glfwInit();
		
		if ( !glfwInit() )
			throw new IllegalStateException("Unable to initialize GLFW");
		
		window = glfwCreateWindow(this.width, this.height, title, (fullscreen ? glfwGetPrimaryMonitor() : 0) , 0);
	
		if(window == 0)
			throw new IllegalStateException("Failed to create window");
		
		if(!fullscreen) {
			GLFWVidMode vid = glfwGetVideoMode(glfwGetPrimaryMonitor());
			glfwSetWindowPos(window, (vid.width()-width)/2, (vid.height()-height)/2);
		}
		
		glfwShowWindow(window);
		
		glfwMakeContextCurrent(window);
		
		input = new Input(window);
	}
	
	public boolean shouldClose() {
		return glfwWindowShouldClose(window);
	}
	
	public void closeWindow() {
		glfwDestroyWindow(window);
		glfwTerminate();
	}
	
	public void setFullscreen(boolean fullscreen) {
		this.fullscreen = fullscreen;
	}
	
	public void update() {
		input.update();
		glfwPollEvents();
	}
	
	public void setSize(int width,int height) {
		this.width = width;
		this.height = height;
	}

	public void swapBuffers() { glfwSwapBuffers(window); } 
	public boolean isFullscreen() { return this.fullscreen; }
	public int getWidth() { return this.width; }
	public int getHeight() { return this.width; }
	public Input getInput() { return input; }
	public long getWindow() { return window; }
}
