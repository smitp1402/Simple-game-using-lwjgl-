package essentials101;


import java.nio.ByteBuffer;
import java.nio.IntBuffer;
import org.lwjgl.stb.STBImage;
import org.lwjgl.system.MemoryStack;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL13.*;


public class Texture {
	private int width;
	private int height;
	private ByteBuffer image;
	private int id;
	
	public Texture() {}
	
	Texture(int width,int height,ByteBuffer image) {
		this.width=width;
		this.height=height;
		this.image=image;
 	}
	
	public Texture setTexture(String path) {
		try(MemoryStack stack=MemoryStack.stackPush()) {
			IntBuffer comp=stack.mallocInt(1);
			IntBuffer w=stack.mallocInt(1);
			IntBuffer h=stack.mallocInt(1);
			image=STBImage.stbi_load("./res/"+path,w,h,comp,4); 	
		    if(image == null) {
		    	System.out.println("COULDN'T LOAD "+path);
		    }
			width=w.get();
			height=h.get();
		}
		return new Texture(width,height,image);
	}
	
	public Texture(String file) {
		this.id=glGenTextures();
		this.setTexture(file);
		glBindTexture(GL_TEXTURE_2D,id);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR);
		glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,width,height,0,GL_RGBA,GL_UNSIGNED_BYTE,image);
		glBindTexture(GL_TEXTURE_2D,0);
	}
	
	public void bind(int sampler) {
		if(sampler>=0&&sampler<=31) {
			glActiveTexture(GL_TEXTURE0+sampler);
			glBindTexture(GL_TEXTURE_2D,id);
		}
	}
//	
//	protected void finalize() throws Throwable{
//		glDeleteTextures(id);
//		super.finalize();
//	}
}
